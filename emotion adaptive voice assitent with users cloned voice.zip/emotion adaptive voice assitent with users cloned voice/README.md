
# 🎙️ Emotion-Adaptive Voice Assistant with Cloned Voice

This project is an intelligent voice assistant that:

1. Takes a **user's text input** (e.g., from speech or typed).
2. Detects the **user's emotion** using NLP.
3. Generates an **emotion-aware response** using a conversational AI model.
4. Speaks the response using a **cloned voice** of the user.

---

### 📁 Folder Structure
```
emotion_voice_assistant/
│
├── main.py                        # Main script to run the assistant
├── emotion_detection.py          # Emotion detection module using transformers
├── response_generation.py        # Assistant response generation with GPT-Neo
├── tts_cloning.py                # Text-to-speech with cloned voice
├── requirements.txt              # All required dependencies
├── README.md                     # This file
└── your_voice_sample.wav         # Your uploaded voice sample (16kHz, clean audio)
```

---

### ⚙️ Requirements

- Python 3.8+
- CUDA-compatible GPU recommended for fast TTS (optional)
- Dependencies:
    ```bash
    pip install -r requirements.txt
    ```

Contents of `requirements.txt`:
```
torch
transformers
TTS==0.21.1
numpy==1.23.5
```

---

### ▶️ How to Run

1. Upload your clean voice sample (`your_voice_sample.wav`) — 10 to 60 seconds.
2. Run the assistant:
    ```bash
    python main.py
    ```
3. Follow the on-screen prompts.

---

### 💡 Features

✅ Emotion detection using fine-tuned DistilBERT  
✅ Context-aware responses using GPT-Neo  
✅ Real-time voice synthesis using your cloned voice  
✅ Modular structure for easy integration with real STT/microphone  
✅ Global state management for full session tracking

---

### 📢 Notes

- Use WAV format audio for voice cloning (16kHz mono recommended).
- Internet connection is required to load models from HuggingFace the first time.
- You can replace the models with your own fine-tuned versions later.

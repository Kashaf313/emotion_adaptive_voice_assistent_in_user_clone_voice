from emotion_detection import detect_and_store_emotion
from response_generation import generate_response, assistant_response
from tts_cloning import speak_with_cloned_voice

def main():
    print("Welcome to Emotion Adaptive Voice Assistant!")
    user_text = input("You: ")

    # Detect emotion
    emotion = detect_and_store_emotion(user_text)
    print(f"🧠 Detected emotion: {emotion}")

    # Generate assistant response
    generate_response()  # This sets global assistant_response
    print(f"🤖 Assistant: {assistant_response}")

    # Ask for your voice sample file path
    voice_sample = input("Enter your voice sample file path (wav): ")

    # Synthesize voice with cloned voice
    audio = speak_with_cloned_voice(assistant_response, voice_sample)
    
    # Play audio (if running in Jupyter or compatible environment)
    try:
        import IPython.display as ipd
        ipd.display(audio)
    except ImportError:
        print("Audio playback not supported in this environment.")

if __name__ == "__main__":
    main()

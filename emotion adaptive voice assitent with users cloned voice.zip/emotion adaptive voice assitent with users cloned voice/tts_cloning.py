from TTS.api import TTS
import IPython.display as ipd

# Load TTS multilingual voice cloning model
tts = TTS(model_name="tts_models/multilingual/multi-dataset/your_tts", progress_bar=False, gpu=True)

voice_sample_path = None  # This should be set to your uploaded wav file path before calling speak

def speak_with_cloned_voice(text, reference_audio):
    output_path = "cloned_output.wav"
    tts.tts_to_file(
        text=text,
        speaker_wav=reference_audio,
        language="en",
        file_path=output_path
    )
    print("✅ Synthesized speech:")
    return ipd.Audio(output_path)

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 3:
        print("Usage: python tts_cloning.py '<text>' <voice_sample_path>")
        exit()

    text = sys.argv[1]
    voice_sample_path = sys.argv[2]

    audio = speak_with_cloned_voice(text, voice_sample_path)
    display(audio)

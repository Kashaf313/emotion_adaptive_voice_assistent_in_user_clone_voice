from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
from emotion_detection import last_user_input, last_detected_emotion

# Load GPT-Neo 1.3B for response generation
model_name = "EleutherAI/gpt-neo-1.3B"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)

# Global variable for assistant's response
assistant_response = None

def generate_response():
    global assistant_response
    user_input = last_user_input
    emotion = last_detected_emotion

    prompt = f"The user is feeling {emotion}. They said: \"{user_input}\"\nAssistant:"

    input_ids = tokenizer.encode(prompt, return_tensors='pt')

    outputs = model.generate(
        input_ids,
        max_length=input_ids.shape[1] + 100,
        min_length=input_ids.shape[1] + 40,
        do_sample=True,
        temperature=0.7,
        top_p=0.9,
        pad_token_id=tokenizer.eos_token_id,
        no_repeat_ngram_size=2,
    )

    reply = tokenizer.decode(outputs[0][input_ids.shape[1]:], skip_special_tokens=True)
    reply = reply.strip().split("User:")[0].split("Assistant:")[0].strip()
    assistant_response = reply
    print(f"🤖 Assistant: {assistant_response}")
    return assistant_response


if __name__ == "__main__":
    generate_response()

from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

model_name = "bhadresh-savani/distilbert-base-uncased-emotion"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForSequenceClassification.from_pretrained(model_name)

labels = ['admiration', 'amusement', 'anger', 'annoyance', 'approval', 'caring',
          'confusion', 'curiosity', 'desire', 'disappointment', 'disapproval',
          'embarrassment', 'excitement', 'fear', 'gratitude', 'grief', 'joy',
          'love', 'nervousness', 'optimism', 'pride', 'realization', 'relief',
          'remorse', 'sadness', 'surprise', 'neutral']

# Global variables
last_user_input = None
last_detected_emotion = None

def detect_and_store_emotion(text):
    global last_user_input, last_detected_emotion
    inputs = tokenizer(text, return_tensors="pt")
    with torch.no_grad():
        logits = model(**inputs).logits
    probs = torch.nn.functional.softmax(logits, dim=-1)
    top_index = torch.argmax(probs, dim=1).item()

    last_user_input = text
    last_detected_emotion = labels[top_index]
    return last_detected_emotion


if __name__ == "__main__":
    user_input = input("You: ")
    emotion = detect_and_store_emotion(user_input)
    print(f"\n🧠 Detected Emotion: **{emotion}**")
